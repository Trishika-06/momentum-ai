import { useEffect, useMemo, useState } from 'react'
import { GENERATE_PLAN_ENDPOINT, INSIGHT_ENDPOINT } from './config'

const initialTasks = [
  {
    title: 'Launch Momentum AI deck',
    description: 'Finalize slides, design system, and deployment checklist.',
    estimate_hours: 2,
  },
  {
    title: 'Build task prioritization flow',
    description: 'Add task form, list UI, and AI planning integration.',
    estimate_hours: 3,
  },
  {
    title: 'Prepare demo script',
    description: 'Write talking points, highlight AI-assisted scheduling.',
    estimate_hours: 1.5,
  },
]

const sectionMeta = {
  'Priority Order': {
    icon: '🔥',
    subtitle: 'Task priority and sequence',
  },
  'Suggested Schedule': {
    icon: '📅',
    subtitle: 'Recommended timing and cadence',
  },
  Reasoning: {
    icon: '💡',
    subtitle: 'Why this plan works',
  },
  'Improvement Suggestions': {
    icon: '⚡',
    subtitle: 'Actions to lighten the load',
  },
}

function parsePlanSections(plan) {
  if (!plan) return []

  const regex = /(Priority Order|Suggested Schedule|Reasoning|Improvement Suggestions)\s*[:\-]*/gi
  const matches = [...plan.matchAll(regex)]

  if (!matches.length) {
    return []
  }

  return matches.map((match, index) => {
    const start = match.index + match[0].length
    const end = index + 1 < matches.length ? matches[index + 1].index : plan.length
    return {
      title: match[1],
      content: plan.slice(start, end).trim(),
    }
  }).filter((section) => section.content)
}

function parseProductivityMetrics(plan, tasks) {
  if (!plan) {
    return {
      productivityScore: null,
      stressLevel: null,
      deadlineRisk: null,
      todaysFocus: null,
    }
  }

  const scoreMatch = plan.match(/Productivity Score\s*[:\-]\s*(\d{1,3})%?/i)
  const stressMatch = plan.match(/Stress Level\s*[:\-]\s*([A-Za-z0-9\s]+)/i)
  const riskMatch = plan.match(/Deadline Risk\s*[:\-]\s*([A-Za-z0-9\s]+)/i)
  const focusMatch = plan.match(/Today's Focus\s*[:\-]\s*([\s\S]*?)(?=\n\s*\n|$)/i)

  return {
    productivityScore: scoreMatch ? `${scoreMatch[1]}%` : null,
    stressLevel: stressMatch ? stressMatch[1].trim() : null,
    deadlineRisk: riskMatch ? riskMatch[1].trim() : null,
    todaysFocus: focusMatch ? focusMatch[1].trim() : null,
  }
}

function App() {
  const [page, setPage] = useState('landing')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [tasks, setTasks] = useState(initialTasks)
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [estimate, setEstimate] = useState(1)
  const [aiPlan, setAiPlan] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [coachQuery, setCoachQuery] = useState('')
  const [coachMessages, setCoachMessages] = useState([])
  const [coachLoading, setCoachLoading] = useState(false)
  const [coachError, setCoachError] = useState('')
  const [aiInsight, setAiInsight] = useState('')
  const [insightLoading, setInsightLoading] = useState(false)
  const [insightError, setInsightError] = useState('')

  const planSections = useMemo(() => parsePlanSections(aiPlan), [aiPlan])
  const productivityMetrics = useMemo(() => parseProductivityMetrics(aiPlan, tasks), [aiPlan, tasks])

  const totalHours = useMemo(() => tasks.reduce((sum, task) => sum + Number(task.estimate_hours), 0), [tasks])

  const handlePageChange = (target) => {
    setError('')
    setPage(target)
  }

  const handleLogin = (event) => {
    event.preventDefault()
    setPage('dashboard')
  }

  const addTask = (event) => {
    event.preventDefault()
    if (!title.trim() || !description.trim()) {
      setError('Give your task a title and description.')
      return
    }

    setTasks((current) => [
      ...current,
      {
        title: title.trim(),
        description: description.trim(),
        estimate_hours: Number(estimate) || 1,
      },
    ])
    setTitle('')
    setDescription('')
    setEstimate(1)
    setError('')
  }

  const removeTask = (index) => {
    setTasks((current) => current.filter((_, taskIndex) => taskIndex !== index))
  }

  const generatePlan = async () => {
    if (!tasks.length) {
      setError('Add at least one task before generating your AI plan.')
      return
    }

    setLoading(true)
    setError('')
    setAiPlan('')

    try {
      const response = await fetch(GENERATE_PLAN_ENDPOINT, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ tasks, username: email || 'Momentum user' }),
      })

      if (!response.ok) {
        const body = await response.text()
        throw new Error(body || 'Gemini API request failed')
      }

      const data = await response.json()
      setAiPlan(data.plan || '')
    } catch (fetchError) {
      setError(fetchError.message || 'Unable to generate AI plan.')
    } finally {
      setLoading(false)
    }
  }

  const fetchInsight = async () => {
    if (!tasks.length) {
      setAiInsight('Add a task to see an AI insight here.')
      return
    }

    setInsightError('')
    setInsightLoading(true)

    try {
      const response = await fetch(INSIGHT_ENDPOINT, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ tasks, username: email || 'Momentum user' }),
      })

      if (!response.ok) {
        const body = await response.text()
        throw new Error(body || 'Insight API request failed')
      }

      const data = await response.json()
      setAiInsight(data.insight || 'Your workload looks good.')
    } catch (fetchError) {
      setInsightError(fetchError.message || 'Unable to load insight.')
      setAiInsight('Your workload looks good.')
    } finally {
      setInsightLoading(false)
    }
  }

  useEffect(() => {
    fetchInsight()
  }, [tasks])

  const sendCoachMessage = async (question) => {
    const prompt = question.trim()
    if (!prompt) return

    setCoachError('')
    setCoachLoading(true)
    setCoachMessages((current) => [...current, { role: 'user', text: prompt }])
    setCoachQuery('')

    try {
      const response = await fetch('/api/coach', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ tasks, username: email || 'Momentum user', question: prompt }),
      })

      if (!response.ok) {
        const body = await response.text()
        throw new Error(body || 'Gemini coaching failed')
      }

      const data = await response.json()
      setCoachMessages((current) => [...current, { role: 'assistant', text: data.response || 'No response from AI.' }])
    } catch (fetchError) {
      setCoachError(fetchError.message || 'Unable to reach the AI coach.')
    } finally {
      setCoachLoading(false)
    }
  }

  const handleCoachSubmit = (event) => {
    event.preventDefault()
    sendCoachMessage(coachQuery)
  }

  const coachSuggestions = [
    'I only have 2 hours.',
    'I am feeling overwhelmed.',
    'What should I postpone?',
    'Give me motivation.',
  ]

  const hasLoginView = page === 'login'
  const hasDashboardView = page === 'dashboard'

  return (
    <div className="min-h-screen bg-slate-950 text-slate-50">
      <div className="relative isolate overflow-hidden px-6 py-8 sm:px-10 lg:px-12">
        <div className="absolute inset-x-0 top-0 -z-10 h-72 bg-gradient-to-b from-cyan-400/20 to-transparent blur-3xl" />
        <header className="mx-auto flex max-w-7xl items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-3xl bg-gradient-to-br from-cyan-400 to-sky-600 text-slate-950 font-extrabold shadow-xl shadow-cyan-500/20">
              M
            </div>
            <div>
              <p className="text-sm font-semibold uppercase tracking-[0.3em] text-cyan-300">Momentum AI</p>
              <p className="text-sm text-slate-400">Smart productivity companion</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => handlePageChange('landing')}
              className="rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm font-semibold text-white/80 transition hover:bg-white/10"
            >
              Landing
            </button>
            <button
              onClick={() => handlePageChange('login')}
              className="rounded-full bg-cyan-400 px-4 py-2 text-sm font-semibold text-slate-950 shadow-lg shadow-cyan-500/20 transition hover:bg-cyan-300"
            >
              Login
            </button>
          </div>
        </header>

        {hasLoginView ? (
          <main className="mx-auto mt-16 max-w-3xl rounded-[2rem] border border-white/10 bg-slate-900/80 p-10 shadow-2xl shadow-slate-950/40 backdrop-blur">
            <div className="space-y-6">
              <div>
                <p className="text-sm font-semibold uppercase tracking-[0.3em] text-cyan-300">Sign in</p>
                <h1 className="mt-4 text-4xl font-semibold tracking-tight text-white">Login to your Momentum workspace.</h1>
                <p className="mt-4 text-slate-400">
                  This is a UI-only login experience for hackathon demo flows.
                </p>
              </div>

              <form onSubmit={handleLogin} className="space-y-5">
                <div>
                  <label className="text-sm font-semibold text-slate-200">Email</label>
                  <input
                    type="email"
                    value={email}
                    onChange={(event) => setEmail(event.target.value)}
                    placeholder="you@example.com"
                    className="mt-2 w-full rounded-3xl border border-white/10 bg-slate-950/90 px-4 py-3 text-white outline-none transition focus:border-cyan-400"
                  />
                </div>

                <div>
                  <label className="text-sm font-semibold text-slate-200">Password</label>
                  <input
                    type="password"
                    value={password}
                    onChange={(event) => setPassword(event.target.value)}
                    placeholder="Enter a password"
                    className="mt-2 w-full rounded-3xl border border-white/10 bg-slate-950/90 px-4 py-3 text-white outline-none transition focus:border-cyan-400"
                  />
                </div>

                {error && (
                  <p className="rounded-3xl bg-rose-500/10 px-4 py-3 text-sm text-rose-200 ring-1 ring-rose-500/20">
                    {error}
                  </p>
                )}

                <button
                  type="submit"
                  className="w-full rounded-3xl bg-cyan-400 px-6 py-4 text-sm font-semibold text-slate-950 shadow-xl shadow-cyan-500/20 transition hover:bg-cyan-300"
                >
                  Continue to Dashboard
                </button>
              </form>
            </div>
          </main>
        ) : hasDashboardView ? (
          <main className="mx-auto mt-16 max-w-7xl space-y-10">
            <section className="rounded-[2rem] border border-white/10 bg-slate-900/80 p-8 shadow-2xl shadow-slate-950/40 backdrop-blur">
              <div className="relative">
                <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                  <div>
                    <p className="text-sm font-semibold uppercase tracking-[0.3em] text-cyan-300">Dashboard</p>
                    <h1 className="mt-4 text-4xl font-semibold tracking-tight text-white">Your productivity hub is ready.</h1>
                    <p className="mt-4 max-w-2xl text-slate-400">
                      Add tasks, track estimated time, and let Gemini craft an intelligent plan for your day.
                    </p>
                  </div>
                  <div className="rounded-3xl bg-slate-950/90 p-5 text-sm text-slate-300 ring-1 ring-white/5">
                    <p className="font-semibold text-white">Total estimated load</p>
                    <p className="mt-3 text-3xl font-semibold text-cyan-300">{totalHours.toFixed(1)} hrs</p>
                    <p className="mt-2 text-slate-500">{tasks.length} tasks · premium AI planning</p>
                  </div>
                </div>

                <div className="pointer-events-none absolute right-0 top-0 hidden w-96 translate-x-1/2 -translate-y-1/2 rounded-[2rem] border border-cyan-400/20 bg-slate-950/95 p-6 text-white shadow-2xl shadow-cyan-500/20 ring-1 ring-cyan-500/10 backdrop-blur md:block">
                  <p className="text-xs font-semibold uppercase tracking-[0.3em] text-cyan-200">AI insight</p>
                  <p className="mt-4 text-lg font-semibold text-white">
                    {insightLoading ? 'Updating insight…' : aiInsight || 'Your workload is balanced.'}
                  </p>
                  {insightError && (
                    <p className="mt-3 text-sm text-rose-300">{insightError}</p>
                  )}
                </div>
              </div>
            </section>

            <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
              {[
                {
                  label: 'Productivity Score',
                  value: productivityMetrics.productivityScore || 'Generate plan',
                  icon: '🚀',
                  hint: 'Efficiency outlook',
                },
                {
                  label: 'Stress Level',
                  value: productivityMetrics.stressLevel || 'Generate plan',
                  icon: '😌',
                  hint: 'Team focus state',
                },
                {
                  label: 'Deadline Risk',
                  value: productivityMetrics.deadlineRisk || 'Generate plan',
                  icon: '⏳',
                  hint: 'Delivery pressure',
                },
                {
                  label: "Today's Focus",
                  value: productivityMetrics.todaysFocus || 'Generate plan',
                  icon: '🎯',
                  hint: 'Top priority for today',
                },
              ].map((card) => (
                <div key={card.label} className="rounded-[2rem] border border-white/10 bg-slate-950/90 p-6 shadow-2xl shadow-slate-950/40 ring-1 ring-white/5">
                  <div className="flex items-center gap-4">
                    <div className="flex h-12 w-12 items-center justify-center rounded-3xl bg-cyan-500/10 text-2xl text-cyan-200">
                      {card.icon}
                    </div>
                    <div>
                      <p className="text-sm font-semibold uppercase tracking-[0.3em] text-cyan-300">{card.label}</p>
                      <p className="mt-1 text-sm text-slate-400">{card.hint}</p>
                    </div>
                  </div>
                  <p className="mt-6 text-3xl font-semibold text-white">{card.value}</p>
                </div>
              ))}
            </section>

            <section className="grid gap-8 lg:grid-cols-[minmax(0,1fr)_420px]">
              <div className="space-y-8">
                <div className="rounded-[2rem] border border-white/10 bg-slate-900/80 p-8 shadow-2xl shadow-slate-950/40 backdrop-blur">
                  <div className="flex items-center justify-between gap-4">
                    <div>
                      <p className="text-sm font-semibold uppercase tracking-[0.3em] text-cyan-300">Add Task</p>
                      <h2 className="mt-4 text-2xl font-semibold text-white">New work item</h2>
                    </div>
                    <span className="rounded-full bg-cyan-500/10 px-3 py-1.5 text-xs font-semibold uppercase text-cyan-200 ring-1 ring-cyan-400/20">
                      AI-ready
                    </span>
                  </div>

                  <form onSubmit={addTask} className="mt-8 space-y-5">
                    <div>
                      <label className="text-sm font-medium text-slate-300">Task title</label>
                      <input
                        value={title}
                        onChange={(event) => setTitle(event.target.value)}
                        placeholder="Design onboarding flow"
                        className="mt-2 w-full rounded-3xl border border-white/10 bg-slate-950/90 px-4 py-3 text-white outline-none transition focus:border-cyan-400"
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium text-slate-300">Description</label>
                      <textarea
                        value={description}
                        onChange={(event) => setDescription(event.target.value)}
                        placeholder="Give your task context, goal, and constraints."
                        rows={4}
                        className="mt-2 w-full rounded-3xl border border-white/10 bg-slate-950/90 px-4 py-3 text-white outline-none transition focus:border-cyan-400"
                      />
                    </div>
                    <div className="grid gap-4 sm:grid-cols-[1fr_120px]">
                      <label className="text-sm font-medium text-slate-300">
                        Estimate (hours)
                        <input
                          type="number"
                          min="0.5"
                          step="0.5"
                          value={estimate}
                          onChange={(event) => setEstimate(event.target.value)}
                          className="mt-2 w-full rounded-3xl border border-white/10 bg-slate-950/90 px-4 py-3 text-white outline-none transition focus:border-cyan-400"
                        />
                      </label>
                      <button
                        type="submit"
                        className="inline-flex items-center justify-center rounded-3xl bg-cyan-400 px-6 py-4 text-sm font-semibold text-slate-950 shadow-xl shadow-cyan-500/20 transition hover:bg-cyan-300"
                      >
                        Add task
                      </button>
                    </div>
                  </form>
                </div>

                <div className="rounded-[2rem] border border-white/10 bg-slate-900/80 p-8 shadow-2xl shadow-slate-950/40 backdrop-blur">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-semibold uppercase tracking-[0.3em] text-cyan-300">Task list</p>
                      <h2 className="mt-4 text-2xl font-semibold text-white">Current backlog</h2>
                    </div>
                    <button
                      onClick={generatePlan}
                      disabled={loading || !tasks.length}
                      className="rounded-3xl bg-cyan-400 px-5 py-3 text-sm font-semibold text-slate-950 shadow-xl shadow-cyan-500/20 transition hover:bg-cyan-300 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                      {loading ? 'Generating…' : 'Generate AI Plan'}
                    </button>
                  </div>

                  <div className="mt-6 space-y-4">
                    {tasks.map((task, index) => (
                      <div key={index} className="rounded-3xl border border-white/10 bg-slate-950/90 p-5">
                        <div className="flex items-start justify-between gap-4">
                          <div>
                            <p className="text-sm font-semibold text-white">{task.title}</p>
                            <p className="mt-2 text-sm leading-6 text-slate-400">{task.description}</p>
                          </div>
                          <div className="flex flex-col items-end gap-3 text-right">
                            <span className="rounded-full bg-slate-800 px-3 py-1 text-xs font-semibold uppercase text-cyan-300">
                              {task.estimate_hours}h
                            </span>
                            <button
                              onClick={() => removeTask(index)}
                              className="text-xs font-semibold uppercase text-rose-300 transition hover:text-rose-100"
                            >
                              Remove
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  {error && (
                    <div className="mt-6 rounded-3xl bg-rose-500/10 p-4 text-sm text-rose-200 ring-1 ring-rose-500/20">
                      {error}
                    </div>
                  )}

                  {totalHours > 10 && (
                    <div className="mt-6 rounded-3xl bg-amber-500/10 p-4 text-sm text-amber-100 ring-1 ring-amber-400/20">
                      Your current load is above 10 hours. Gemini will suggest ways to rebalance the plan.
                    </div>
                  )}
                </div>
              </div>

              <div className="space-y-8">
                <div className="rounded-[2rem] border border-white/10 bg-slate-900/80 p-8 shadow-2xl shadow-slate-950/40 backdrop-blur">
                  <p className="text-sm font-semibold uppercase tracking-[0.3em] text-cyan-300">AI plan preview</p>
                  <h2 className="mt-4 text-2xl font-semibold text-white">Gemini insights</h2>
                  <p className="mt-3 text-slate-400">
                    The AI will prioritize your tasks, craft a schedule, explain the order, and suggest improvements if your workload is too much.
                  </p>
                </div>

                {aiPlan && (
                  <div className="space-y-6">
                    <div className="rounded-[2rem] border border-white/10 bg-slate-900/80 p-8 shadow-2xl shadow-slate-950/40 backdrop-blur">
                      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                        <div>
                          <p className="text-sm font-semibold uppercase tracking-[0.3em] text-cyan-300">AI Result</p>
                          <h2 className="mt-3 text-2xl font-semibold text-white">Gemini strategy breakdown</h2>
                        </div>
                        <span className="inline-flex items-center justify-center rounded-full bg-cyan-500/10 px-4 py-2 text-xs font-semibold uppercase text-cyan-200 ring-1 ring-cyan-400/20">
                          Premium insights
                        </span>
                      </div>
                    </div>

                    <div className="grid gap-5 md:grid-cols-2">
                      {planSections.length ? planSections.map((section) => {
                        const meta = sectionMeta[section.title] || {}
                        return (
                          <div key={section.title} className="rounded-[2rem] border border-white/10 bg-slate-950/90 p-6 shadow-2xl shadow-slate-950/40 ring-1 ring-white/5">
                            <div className="flex items-start gap-4">
                              <div className="flex h-12 w-12 items-center justify-center rounded-3xl bg-cyan-500/10 text-2xl text-cyan-200">
                                {meta.icon || '✨'}
                              </div>
                              <div>
                                <p className="text-sm font-semibold uppercase tracking-[0.3em] text-cyan-300">{section.title}</p>
                                <p className="mt-1 text-sm text-slate-400">{meta.subtitle || 'AI-generated insight'}</p>
                              </div>
                            </div>
                            <div className="mt-6 whitespace-pre-line text-slate-100 text-sm leading-7">{section.content}</div>
                          </div>
                        )
                      }) : (
                        <div className="rounded-[2rem] border border-white/10 bg-slate-950/90 p-6 shadow-2xl shadow-slate-950/40 ring-1 ring-white/5">
                          <p className="text-sm font-semibold uppercase tracking-[0.3em] text-cyan-300">AI Result</p>
                          <div className="mt-4 whitespace-pre-line text-slate-100 text-sm leading-7">{aiPlan}</div>
                        </div>
                      )}
                    </div>
                  </div>
                )}
                <div className="rounded-[2rem] border border-white/10 bg-slate-900/80 p-8 shadow-2xl shadow-slate-950/40 backdrop-blur">
                  <div className="flex items-center justify-between gap-4">
                    <div>
                      <p className="text-sm font-semibold uppercase tracking-[0.3em] text-cyan-300">AI Coach</p>
                      <h2 className="mt-4 text-2xl font-semibold text-white">Ask Gemini for personalized guidance.</h2>
                    </div>
                    <span className="rounded-full bg-slate-800/90 px-3 py-1.5 text-xs font-semibold uppercase text-cyan-200 ring-1 ring-white/10">
                      On-demand coach
                    </span>
                  </div>

                  <div className="mt-8 space-y-4">
                    <div className="rounded-3xl bg-slate-950/90 p-5 ring-1 ring-white/5">
                      {coachMessages.length ? (
                        <div className="space-y-4">
                          {coachMessages.map((message, idx) => (
                            <div key={idx} className={`rounded-3xl px-4 py-3 ${message.role === 'assistant' ? 'bg-cyan-500/10 text-cyan-100' : 'bg-slate-800/80 text-slate-200'}`}>
                              <p className="text-xs uppercase tracking-[0.3em] text-slate-400">{message.role === 'assistant' ? 'Coach' : 'You'}</p>
                              <p className="mt-2 text-sm leading-6">{message.text}</p>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-sm leading-6 text-slate-400">
                          Ask the coach a question about your tasks, focus, deadlines, or motivation.
                        </p>
                      )}
                    </div>

                    <form onSubmit={handleCoachSubmit} className="space-y-4">
                      <label className="block text-sm font-medium text-slate-300">Your question</label>
                      <textarea
                        value={coachQuery}
                        onChange={(event) => setCoachQuery(event.target.value)}
                        placeholder="What should I tackle first if I have only 2 hours?"
                        rows={4}
                        className="w-full rounded-3xl border border-white/10 bg-slate-950/90 px-4 py-3 text-white outline-none transition focus:border-cyan-400"
                      />
                      {coachError && (
                        <p className="rounded-3xl bg-rose-500/10 px-4 py-3 text-sm text-rose-200 ring-1 ring-rose-500/20">
                          {coachError}
                        </p>
                      )}
                      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                        <button
                          type="submit"
                          disabled={coachLoading}
                          className="inline-flex items-center justify-center rounded-3xl bg-cyan-400 px-6 py-4 text-sm font-semibold text-slate-950 shadow-xl shadow-cyan-500/20 transition hover:bg-cyan-300 disabled:cursor-not-allowed disabled:opacity-50"
                        >
                          {coachLoading ? 'Asking coach…' : 'Ask AI Coach'}
                        </button>
                        <div className="grid flex-1 gap-2 sm:grid-cols-2">
                          {coachSuggestions.map((suggestion) => (
                            <button
                              key={suggestion}
                              type="button"
                              onClick={() => sendCoachMessage(suggestion)}
                              className="rounded-3xl border border-white/10 bg-slate-950/90 px-4 py-3 text-left text-sm text-slate-300 transition hover:border-cyan-400 hover:text-white"
                            >
                              {suggestion}
                            </button>
                          ))}
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </section>
          </main>
        ) : (
          <main className="mx-auto mt-16 max-w-7xl lg:mt-24">
            <div className="grid gap-14 lg:grid-cols-[minmax(0,1fr)_420px] lg:items-center lg:gap-20">
              <div>
                <p className="text-sm font-semibold uppercase tracking-[0.3em] text-cyan-300">Build momentum, avoid last-minute stress</p>
                <h1 className="mt-6 text-4xl font-semibold tracking-tight text-white sm:text-5xl lg:text-6xl">
                  Your AI Productivity Companion.
                </h1>
                <p className="mt-6 max-w-2xl text-lg leading-8 text-slate-300">
                  Momentum helps you prioritize work, reduce stress, adapt your plans, and stay productive with intelligent AI guidance.
                </p>
                <div className="mt-10 flex flex-col gap-4 sm:flex-row sm:items-center">
                  <button
                    onClick={() => handlePageChange('login')}
                    className="inline-flex w-full items-center justify-center rounded-full bg-cyan-400 px-8 py-4 text-base font-semibold text-slate-950 shadow-xl shadow-cyan-500/20 transition hover:bg-cyan-300 sm:w-auto"
                  >
                    Start your flow
                  </button>
                  <button
                    onClick={() => handlePageChange('dashboard')}
                    className="inline-flex w-full items-center justify-center rounded-full border border-white/10 bg-white/5 px-8 py-4 text-base font-semibold text-white/80 transition hover:text-white sm:w-auto"
                  >
                    Explore the experience
                  </button>
                </div>
              </div>

              <div className="relative">
                <div className="absolute -right-10 top-1/2 -z-10 h-56 w-56 rounded-full bg-cyan-500/20 blur-3xl" />
                <div className="overflow-hidden rounded-[2rem] border border-white/10 bg-slate-900/80 p-8 shadow-2xl shadow-slate-950/40 backdrop-blur">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <p className="text-sm font-semibold uppercase tracking-[0.25em] text-cyan-300">Momentum Board</p>
                      <h2 className="mt-4 text-3xl font-semibold text-white">Plan your peak productivity.</h2>
                    </div>
                    <span className="rounded-full bg-cyan-500/10 px-3 py-1.5 text-xs font-semibold uppercase text-cyan-200 ring-1 ring-cyan-400/20">
                      AI Premium
                    </span>
                  </div>

                  <div className="mt-8 space-y-5">
                    <div className="rounded-3xl bg-slate-950/90 p-5 ring-1 ring-white/5">
                      <div className="flex items-center justify-between gap-3">
                        <p className="text-sm font-medium text-slate-400">Focus task</p>
                        <span className="rounded-full bg-slate-800 px-3 py-1 text-xs font-semibold text-cyan-300">High</span>
                      </div>
                      <p className="mt-4 text-xl font-semibold text-white">Finalize momentum deck</p>
                      <p className="mt-2 text-sm leading-6 text-slate-500">
                        AI-crafted schedule, clarity cues, and timing suggestions for your most important work.
                      </p>
                    </div>
                    <div className="rounded-3xl bg-slate-950/90 p-5 ring-1 ring-white/5">
                      <div className="flex items-center justify-between text-sm text-slate-400">
                        <span>Focus window</span>
                        <span>2 hrs left</span>
                      </div>
                      <div className="mt-4 flex items-center gap-3">
                        <div className="h-3 flex-1 overflow-hidden rounded-full bg-slate-800">
                          <div className="h-full w-3/4 rounded-full bg-cyan-400" />
                        </div>
                        <span className="text-xs font-semibold uppercase text-slate-500">75%</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </main>
        )}
      </div>
    </div>
  )
}

export default App;
