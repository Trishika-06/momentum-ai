from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from google import genai
import os

load_dotenv()

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
GEMINI_API_KEY = os.getenv('GEMINI_API_KEY')

if not GEMINI_API_KEY:
    raise RuntimeError('Missing GEMINI_API_KEY in environment')

client = genai.Client(api_key=GEMINI_API_KEY)

class TaskItem(BaseModel):
    title: str
    description: str
    estimate_hours: float

class GeneratePlanRequest(BaseModel):
    username: str
    tasks: list[TaskItem]

class CoachRequest(BaseModel):
    username: str
    tasks: list[TaskItem]
    question: str

class InsightRequest(BaseModel):
    username: str
    tasks: list[TaskItem]

@app.post('/api/generate-plan')
def generate_plan(request: GeneratePlanRequest):
    prompt_lines = [
        f"Task: {task.title}\nDescription: {task.description}\nEstimated hours: {task.estimate_hours}" for task in request.tasks
    ]
    prompt = (
        "You are an expert productivity coach for a hackathon team. "
        "Use the tasks below to do the following:\n"
        "1. Prioritize the tasks in the best order.\n"
        "2. Create a schedule for the day.\n"
        "3. Explain why the order was chosen.\n"
        "4. Suggest improvements if the workload is too much.\n\n"
        f"User: {request.username}\n\n"
        "Tasks:\n"
        + '\n---\n'.join(prompt_lines)
        + "\n\nOutput a clear plan with a priority list, schedule, reasoning, and improvement suggestions."
    )

    try:
        response = client.models.generate_content(
            model='gemini-2.5-flash',
            contents=[prompt],
            config={
                'temperature': 0.7,
                'max_output_tokens': 512,
                'top_p': 0.95,
            },
        )
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc))

    if not response.candidates:
        raise HTTPException(status_code=502, detail='Gemini returned no candidates')

    candidate = response.candidates[0]
    plan_text = ''

    if candidate.content and candidate.content.parts:
        part = candidate.content.parts[0]
        plan_text = getattr(part, 'text', '') or ''

    if not plan_text:
        raise HTTPException(status_code=502, detail='Gemini returned no text output')

    return {'plan': plan_text}

@app.post('/api/coach')
def coach(request: CoachRequest):
    prompt_lines = [
        f"Task: {task.title}\nDescription: {task.description}\nEstimated hours: {task.estimate_hours}" for task in request.tasks
    ]
    prompt = (
        "You are a supportive productivity coach for a hackathon team. "
        "Use the tasks below to answer the user’s question with empathy, useful prioritization advice, and practical motivation. "
        "The user may ask about limited time, feeling overwhelmed, what to postpone, or seeking motivation.\n\n"
        f"User: {request.username}\n\n"
        "Tasks:\n"
        + '\n---\n'.join(prompt_lines)
        + "\n\nQuestion:\n"
        + request.question.strip()
        + "\n\nAnswer clearly and concisely, focusing on actionable next steps."
    )

    try:
        response = client.models.generate_content(
            model='gemini-2.5-flash',
            contents=[prompt],
            config={
                'temperature': 0.7,
                'max_output_tokens': 512,
                'top_p': 0.95,
            },
        )
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc))

    if not response.candidates:
        raise HTTPException(status_code=502, detail='Gemini returned no candidates')

    candidate = response.candidates[0]
    coach_text = ''

    if candidate.content and candidate.content.parts:
        part = candidate.content.parts[0]
        coach_text = getattr(part, 'text', '') or ''

    if not coach_text:
        raise HTTPException(status_code=502, detail='Gemini returned no text output')

    return {'response': coach_text}

@app.post('/api/insight')
def insight(request: InsightRequest):
    if not request.tasks:
        return {'insight': 'Add a task to get a quick AI productivity insight.'}

    prompt_lines = [
        f"Task: {task.title}\nDescription: {task.description}\nEstimated hours: {task.estimate_hours}" for task in request.tasks
    ]
    prompt = (
        "You are an AI productivity companion. Review the user’s tasks and provide one concise insight about their current workload. "
        "The insight should be a short observation or recommendation like 'Your workload is balanced.' or 'Move coding before shopping because it requires higher concentration.'\n\n"
        f"User: {request.username}\n\n"
        "Tasks:\n"
        + '\n---\n'.join(prompt_lines)
        + "\n\nProvide a single clear insight in one or two sentences."
    )

    try:
        response = client.models.generate_content(
            model='gemini-2.5-flash',
            contents=[prompt],
            config={
                'temperature': 0.7,
                'max_output_tokens': 80,
                'top_p': 0.95,
            },
        )
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc))

    if not response.candidates:
        raise HTTPException(status_code=502, detail='Gemini returned no candidates')

    candidate = response.candidates[0]
    insight_text = ''

    if candidate.content and candidate.content.parts:
        part = candidate.content.parts[0]
        insight_text = getattr(part, 'text', '') or ''

    if not insight_text:
        raise HTTPException(status_code=502, detail='Gemini returned no text output')

    return {'insight': insight_text.strip()}

if __name__ == '__main__':
    import uvicorn

    uvicorn.run(app, host='127.0.0.1', port=8000)
